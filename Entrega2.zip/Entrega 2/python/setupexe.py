from distutils.core import setup
import py2exe

setup(console=["4096.py"])

'''
Ejecutar
	C:\Python34\python setupexe.py py2exe
en el terminal de windows
'''